<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Shorten Link</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

</head>
<body>
    <div class="container mt-5">
        <h2>Laravel - Create URL Shortener</h2>
        
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <form method="post" action="<?php echo e(route('generate.shorten.link.post')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="input-group mb-3">
                        <input type="text" name="link" class="form-control" placeholder="Enter URL">
                        
                        <div class="input-group-addon">
                            <button class="btn btn-success">Generate Shorten Link</button>
                        </div>
                                                
                    </div>
                    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="m-0 p-0 text text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </form>
            </div>
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Short Link</th>
                    <th>Link</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $shortLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <tr>
                    <td><?php echo e($row->id); ?></td>
                    <td><a href="<?php echo e(route('shorten.link',$row->code)); ?>" target="_blank"><?php echo e(route('shorten.link',$row->code)); ?></a> </td>
                    <td><?php echo e($row->link); ?></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\0-ActiveLamp\shortlink\resources\views/shortenLink.blade.php ENDPATH**/ ?>